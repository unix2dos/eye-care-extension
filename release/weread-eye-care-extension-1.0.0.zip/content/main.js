// src/shared/constants.ts
var DEFAULT_POLICY = {
  inactivityTimeoutMs: 3 * 6e4,
  reminderIntervalMs: 20 * 6e4
};
var DEFAULT_REMINDER_SETTINGS = {
  reminderIntervalMinutes: 20,
  audioEnabled: true,
  fullscreenReminder: true
};

// src/shared/messages.ts
var TOOLBAR_ICON_STATE_COMMAND = "toolbar-icon-state";

// src/shared/stats.ts
function createBookStats(title) {
  return {
    title,
    readingTimeMs: 0,
    reminderCount: 0
  };
}
function createDayStats(date) {
  return {
    date,
    readingTimeMs: 0,
    reminderCount: 0,
    books: {}
  };
}
function ensureDay(state, date) {
  const existing = state.days[date];
  if (existing) {
    return existing;
  }
  const created = createDayStats(date);
  state.days[date] = created;
  return created;
}
function ensureBook(day, bookTitle) {
  const existing = day.books[bookTitle];
  if (existing) {
    return existing;
  }
  const created = createBookStats(bookTitle);
  day.books[bookTitle] = created;
  return created;
}
function createEmptyStatsState() {
  return { days: {} };
}
function recordReadingSample(state, sample) {
  const day = ensureDay(state, sample.date);
  const book = ensureBook(day, sample.bookTitle);
  day.readingTimeMs += sample.readingTimeMs;
  book.readingTimeMs += sample.readingTimeMs;
}
function recordReminderTriggered(state, reminder) {
  const day = ensureDay(state, reminder.date);
  const book = ensureBook(day, reminder.bookTitle);
  day.reminderCount += 1;
  book.reminderCount += 1;
}
function normalizeBookStats(bookTitle, book) {
  if (!book || typeof book !== "object") {
    return createBookStats(bookTitle);
  }
  const raw = book;
  return {
    title: typeof raw.title === "string" ? raw.title : bookTitle,
    readingTimeMs: typeof raw.readingTimeMs === "number" ? raw.readingTimeMs : 0,
    reminderCount: typeof raw.reminderCount === "number" ? raw.reminderCount : 0
  };
}
function normalizeDayStats(date, day) {
  if (!day || typeof day !== "object") {
    return createDayStats(date);
  }
  const raw = day;
  const books = Object.fromEntries(
    Object.entries(raw.books ?? {}).map(([bookTitle, book]) => [bookTitle, normalizeBookStats(bookTitle, book)])
  );
  return {
    date: typeof raw.date === "string" ? raw.date : date,
    readingTimeMs: typeof raw.readingTimeMs === "number" ? raw.readingTimeMs : 0,
    reminderCount: typeof raw.reminderCount === "number" ? raw.reminderCount : 0,
    books
  };
}
function normalizeStatsState(state) {
  if (!state || typeof state !== "object") {
    return createEmptyStatsState();
  }
  const raw = state;
  return {
    days: Object.fromEntries(Object.entries(raw.days ?? {}).map(([date, day]) => [date, normalizeDayStats(date, day)]))
  };
}

// src/shared/storage.ts
var STORAGE_KEY = "weread-eye-care-state";
function getDefaultState() {
  return {
    stats: createEmptyStatsState(),
    activeReadingTimeMs: 0,
    isActiveReading: false,
    nextEligibleReminderAt: null,
    settings: DEFAULT_REMINDER_SETTINGS
  };
}
function normalizeSettings(stored) {
  if (!stored || typeof stored !== "object") {
    return DEFAULT_REMINDER_SETTINGS;
  }
  const raw = stored;
  const reminderIntervalMinutes = raw.reminderIntervalMinutes === 15 || raw.reminderIntervalMinutes === 20 || raw.reminderIntervalMinutes === 30 ? raw.reminderIntervalMinutes : DEFAULT_REMINDER_SETTINGS.reminderIntervalMinutes;
  return {
    reminderIntervalMinutes,
    audioEnabled: typeof raw.audioEnabled === "boolean" ? raw.audioEnabled : DEFAULT_REMINDER_SETTINGS.audioEnabled,
    fullscreenReminder: typeof raw.fullscreenReminder === "boolean" ? raw.fullscreenReminder : DEFAULT_REMINDER_SETTINGS.fullscreenReminder
  };
}
function normalizeState(stored) {
  if (!stored || typeof stored !== "object") {
    return getDefaultState();
  }
  const raw = stored;
  return {
    stats: normalizeStatsState(raw.stats),
    activeReadingTimeMs: typeof raw.activeReadingTimeMs === "number" ? raw.activeReadingTimeMs : 0,
    isActiveReading: typeof raw.isActiveReading === "boolean" ? raw.isActiveReading : false,
    nextEligibleReminderAt: typeof raw.nextEligibleReminderAt === "number" ? raw.nextEligibleReminderAt : null,
    settings: normalizeSettings(raw.settings)
  };
}
var AppStorage = class {
  constructor(storageArea = chrome.storage.local) {
    this.storageArea = storageArea;
  }
  async loadState() {
    const data = await this.storageArea.get(STORAGE_KEY);
    return normalizeState(data[STORAGE_KEY]);
  }
  async saveState(state) {
    await this.storageArea.set({ [STORAGE_KEY]: state });
  }
  async loadStats() {
    const state = await this.loadState();
    return state.stats;
  }
  async saveStats(stats) {
    const state = await this.loadState();
    await this.saveState({ ...state, stats });
  }
  async setRuntimeStatus(status) {
    const state = await this.loadState();
    await this.saveState({ ...state, ...status });
  }
  async saveSettings(settings) {
    const state = await this.loadState();
    await this.saveState({ ...state, settings });
  }
  async resetState() {
    await this.saveState(getDefaultState());
  }
};

// src/content/activity/session.ts
var ActiveReadingSession = class {
  constructor(inactivityTimeoutMs) {
    this.inactivityTimeoutMs = inactivityTimeoutMs;
  }
  isVisible = true;
  activeSince = null;
  lastInteractionAt = null;
  markInteraction(now) {
    if (!this.isVisible) {
      return;
    }
    if (this.activeSince === null) {
      this.activeSince = now;
    }
    this.lastInteractionAt = now;
  }
  setVisibility(isVisible, _now) {
    this.isVisible = isVisible;
    if (!isVisible) {
      this.activeSince = null;
      this.lastInteractionAt = null;
    }
  }
  isActive(now) {
    return this.isVisible && this.lastInteractionAt !== null && now - this.lastInteractionAt <= this.inactivityTimeoutMs;
  }
  getActiveReadingSince(now) {
    return this.isActive(now) ? this.activeSince : null;
  }
};

// src/content/reminder/tts.ts
var DEFAULT_REMINDER_SPEECH = "\u8BF7\u4F11\u606F\u4E00\u4E0B\uFF0C\u7728\u773C\u51E0\u6B21\uFF0C\u518D\u770B\u8FDC\u5904\u5341\u79D2\u3002";

// src/content/preview.ts
var PREVIEW_REMINDER_MESSAGE = DEFAULT_REMINDER_SPEECH;
function createPreviewReminderRunner({
  overlay,
  playReminder,
  getPresentation = () => "fullscreen"
}) {
  return async () => {
    const dismissed = overlay.show(PREVIEW_REMINDER_MESSAGE, "preview", getPresentation());
    await playReminder().catch(() => void 0);
    await dismissed;
  };
}

// src/content/reminder/audio.ts
var DEFAULT_REMINDER_AUDIO_PATH = "audio/reminder.m4a";
function createDisabledReminderAudioDebugInfo(getAssetUrl = (path) => chrome.runtime.getURL(path)) {
  return {
    sourceUrl: getAssetUrl(DEFAULT_REMINDER_AUDIO_PATH),
    playbackKind: "bundled-audio",
    status: "disabled",
    errorMessage: null
  };
}
function createReminderAudioPlayer({
  getAssetUrl = (path) => chrome.runtime.getURL(path),
  createAudio = (src) => {
    const audio = new Audio(src);
    audio.preload = "auto";
    return audio;
  }
} = {}) {
  const sourceUrl = getAssetUrl(DEFAULT_REMINDER_AUDIO_PATH);
  const audio = createAudio(sourceUrl);
  return async () => {
    audio.pause();
    try {
      audio.currentTime = 0;
    } catch {
    }
    try {
      await audio.play();
      return {
        sourceUrl,
        playbackKind: "bundled-audio",
        status: "played",
        errorMessage: null
      };
    } catch (error) {
      return {
        sourceUrl,
        playbackKind: "bundled-audio",
        status: "play-failed",
        errorMessage: error instanceof Error ? error.message : String(error)
      };
    }
  };
}

// src/content/reminder/overlay.ts
var OVERLAY_ID = "weread-eye-care-overlay";
var DISMISS_BUTTON_LABEL = "\u6211\u77E5\u9053\u4E86";
function ensureOverlayElement(doc) {
  const existing = doc.getElementById(OVERLAY_ID);
  if (existing instanceof HTMLDivElement) {
    return existing;
  }
  const element = doc.createElement("div");
  element.id = OVERLAY_ID;
  element.style.position = "fixed";
  element.style.inset = "0";
  element.style.zIndex = "2147483647";
  element.style.display = "none";
  element.style.alignItems = "center";
  element.style.justifyContent = "center";
  element.style.padding = "32px";
  element.style.background = "rgba(14, 16, 19, 0.94)";
  element.style.color = "#f6f3ec";
  element.style.font = "15px/1.6 -apple-system, BlinkMacSystemFont, sans-serif";
  element.style.pointerEvents = "auto";
  element.innerHTML = `
    <div
      style="
        width: min(560px, 100%);
        padding: 32px 28px;
        border-radius: 24px;
        background: #f7f1e7;
        color: #1d1c19;
        box-shadow: 0 30px 80px rgba(0, 0, 0, 0.32);
        text-align: center;
      "
    >
      <div
        data-role="message"
        style="
          font-size: 28px;
          line-height: 1.5;
          font-weight: 700;
          margin-bottom: 24px;
        "
      ></div>
      <button
        type="button"
        data-role="dismiss"
        style="
          min-width: 180px;
          padding: 14px 22px;
          border: none;
          border-radius: 999px;
          background: #1d1c19;
          color: #f7f1e7;
          font-size: 18px;
          font-weight: 700;
          cursor: pointer;
        "
      >${DISMISS_BUTTON_LABEL}</button>
    </div>
  `;
  (doc.body ?? doc.documentElement).appendChild(element);
  return element;
}
var ReminderOverlay = class {
  doc;
  element;
  panelElement;
  messageElement;
  dismissButton;
  dismissPromise = null;
  resolveDismiss = null;
  activeMode = null;
  activePresentation = null;
  previousHtmlOverflow = "";
  previousBodyOverflow = "";
  constructor(doc) {
    this.doc = doc;
    this.element = ensureOverlayElement(doc);
    const panelElement = this.element.firstElementChild;
    const messageElement = this.element.querySelector('[data-role="message"]');
    const dismissButton = this.element.querySelector('[data-role="dismiss"]');
    if (!(panelElement instanceof HTMLDivElement) || !(messageElement instanceof HTMLDivElement) || !(dismissButton instanceof HTMLButtonElement)) {
      throw new Error("Reminder overlay structure is incomplete.");
    }
    this.panelElement = panelElement;
    this.messageElement = messageElement;
    this.dismissButton = dismissButton;
    this.dismissButton.addEventListener("click", () => {
      this.hide();
    });
  }
  applyPresentation(presentation) {
    if (presentation === "compact") {
      this.element.style.inset = "auto 24px 24px auto";
      this.element.style.padding = "0";
      this.element.style.background = "transparent";
      this.element.style.display = "block";
      this.element.style.width = "min(360px, calc(100vw - 48px))";
      this.panelElement.style.width = "100%";
      this.panelElement.style.padding = "20px 20px 18px";
      this.panelElement.style.borderRadius = "18px";
      this.messageElement.style.fontSize = "22px";
      this.messageElement.style.marginBottom = "18px";
      return;
    }
    this.element.style.inset = "0";
    this.element.style.padding = "32px";
    this.element.style.background = "rgba(14, 16, 19, 0.94)";
    this.element.style.display = "flex";
    this.element.style.width = "";
    this.panelElement.style.width = "min(560px, 100%)";
    this.panelElement.style.padding = "32px 28px";
    this.panelElement.style.borderRadius = "24px";
    this.messageElement.style.fontSize = "28px";
    this.messageElement.style.marginBottom = "24px";
  }
  show(message, mode = "reminder", presentation = "fullscreen") {
    this.activeMode = mode;
    this.activePresentation = presentation;
    this.messageElement.textContent = message;
    this.applyPresentation(presentation);
    if (presentation === "fullscreen") {
      this.previousHtmlOverflow = this.doc.documentElement.style.overflow;
      this.previousBodyOverflow = this.doc.body.style.overflow;
      this.doc.documentElement.style.overflow = "hidden";
      this.doc.body.style.overflow = "hidden";
    }
    this.dismissButton.focus();
    if (!this.dismissPromise) {
      this.dismissPromise = new Promise((resolve) => {
        this.resolveDismiss = resolve;
      });
    }
    return this.dismissPromise;
  }
  hide() {
    this.activeMode = null;
    this.activePresentation = null;
    this.element.style.display = "none";
    this.doc.documentElement.style.overflow = this.previousHtmlOverflow;
    this.doc.body.style.overflow = this.previousBodyOverflow;
    const resolve = this.resolveDismiss;
    this.dismissPromise = null;
    this.resolveDismiss = null;
    resolve?.();
  }
  isBlockingReminderVisible() {
    return this.element.style.display !== "none" && this.activeMode === "reminder" && this.activePresentation === "fullscreen";
  }
  isVisible() {
    return this.element.style.display !== "none";
  }
};

// src/content/runtime/scheduler.ts
var ActiveReadingReminderScheduler = class {
  accumulatedActiveReadingMs;
  lastUpdatedAt = null;
  wasActive = false;
  reminderIntervalMs;
  constructor(reminderIntervalMs, initialActiveReadingTimeMs = 0) {
    this.reminderIntervalMs = reminderIntervalMs;
    this.accumulatedActiveReadingMs = initialActiveReadingTimeMs;
  }
  setReminderIntervalMs(reminderIntervalMs) {
    this.reminderIntervalMs = reminderIntervalMs;
  }
  update(now, isActive) {
    if (this.lastUpdatedAt !== null && this.wasActive && isActive) {
      this.accumulatedActiveReadingMs += Math.max(0, now - this.lastUpdatedAt);
    }
    this.lastUpdatedAt = now;
    this.wasActive = isActive;
    const reminderDue = this.accumulatedActiveReadingMs >= this.reminderIntervalMs;
    return {
      activeReadingTimeMs: this.accumulatedActiveReadingMs,
      reminderDue,
      nextReminderAt: isActive ? now + Math.max(0, this.reminderIntervalMs - this.accumulatedActiveReadingMs) : null,
      isActive
    };
  }
  markReminderTriggered(now) {
    this.accumulatedActiveReadingMs = 0;
    this.lastUpdatedAt = now;
  }
};

// src/content/weread/adapter.ts
var WEREAD_READER_PATH = "/web/reader/";
var TITLE_SELECTORS = [".readerTopBar_title_txt", ".readerCatalog_bookInfo_title"];
function isSupportedWeReadUrl(url) {
  return url.hostname === "weread.qq.com" && url.pathname.startsWith(WEREAD_READER_PATH);
}
function cleanDocumentTitle(title) {
  return title.replace(/\s*-\s*微信读书$/, "").trim();
}
function getWeReadBookTitle(doc) {
  for (const selector of TITLE_SELECTORS) {
    const element = doc.querySelector(selector);
    const text = element?.textContent?.trim() ?? element?.innerText?.trim();
    if (text) {
      return text;
    }
  }
  return cleanDocumentTitle(doc.title) || "\u672A\u547D\u540D\u4E66\u7C4D";
}

// src/content/main.ts
var STATS_SAMPLE_INTERVAL_MS = 5e3;
function getReminderIntervalMs(settings) {
  return settings.reminderIntervalMinutes * 6e4;
}
function getReminderPresentation(settings) {
  return settings.fullscreenReminder ? "fullscreen" : "compact";
}
function areSettingsEqual(left, right) {
  return left.reminderIntervalMinutes === right.reminderIntervalMinutes && left.audioEnabled === right.audioEnabled && left.fullscreenReminder === right.fullscreenReminder;
}
function getTodayDate() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function bootstrap(doc, win) {
  doc.documentElement.dataset.wereadEyeCareBootMarker = "booted";
  const url = new URL(win.location.href);
  if (!isSupportedWeReadUrl(url)) {
    return;
  }
  const overlay = new ReminderOverlay(doc);
  const storage = new AppStorage();
  const persisted = await storage.loadState();
  const session = new ActiveReadingSession(DEFAULT_POLICY.inactivityTimeoutMs);
  const scheduler = new ActiveReadingReminderScheduler(
    getReminderIntervalMs(persisted.settings),
    persisted.activeReadingTimeMs
  );
  const playReminderAudio = createReminderAudioPlayer();
  let stats = persisted.stats;
  let nextEligibleReminderAt = persisted.nextEligibleReminderAt;
  let activeReadingTimeMs = persisted.activeReadingTimeMs;
  let isActiveReading = persisted.isActiveReading;
  let settings = persisted.settings ?? DEFAULT_REMINDER_SETTINGS;
  const reportToolbarIconState = async (nextIsActiveReading) => {
    try {
      await chrome.runtime.sendMessage({
        type: TOOLBAR_ICON_STATE_COMMAND,
        isSupportedPage: true,
        isActiveReading: nextIsActiveReading
      });
    } catch {
    }
  };
  const persistRuntimeStatus = async (nextStatus) => {
    const nextActiveReadingTimeMs = nextStatus.activeReadingTimeMs ?? activeReadingTimeMs;
    const nextIsActiveReading = nextStatus.isActiveReading ?? isActiveReading;
    const nextReminderAt = nextStatus.nextEligibleReminderAt === void 0 ? nextEligibleReminderAt : nextStatus.nextEligibleReminderAt;
    if (nextActiveReadingTimeMs === activeReadingTimeMs && nextIsActiveReading === isActiveReading && nextReminderAt === nextEligibleReminderAt) {
      return;
    }
    const shouldReportToolbarState = nextIsActiveReading !== isActiveReading;
    activeReadingTimeMs = nextActiveReadingTimeMs;
    isActiveReading = nextIsActiveReading;
    nextEligibleReminderAt = nextReminderAt;
    await storage.setRuntimeStatus({
      activeReadingTimeMs,
      isActiveReading,
      nextEligibleReminderAt
    });
    if (shouldReportToolbarState) {
      await reportToolbarIconState(isActiveReading);
    }
  };
  const persistStats = async () => {
    await storage.saveStats(stats);
  };
  const syncSchedule = async (now) => {
    const schedule = scheduler.update(now, session.isActive(now));
    await persistRuntimeStatus({
      activeReadingTimeMs: schedule.activeReadingTimeMs,
      isActiveReading: schedule.isActive,
      nextEligibleReminderAt: schedule.isActive ? schedule.nextReminderAt : null
    });
    return schedule;
  };
  const recordReminderAudioDebug = (debugInfo) => {
    doc.documentElement.dataset.wereadEyeCareReminderAudioPath = debugInfo.sourceUrl;
    doc.documentElement.dataset.wereadEyeCareReminderAudioStatus = debugInfo.status;
    doc.documentElement.dataset.wereadEyeCareReminderAudioErrorMessage = debugInfo.errorMessage ?? "";
  };
  const playReminder = async () => {
    const debugInfo = settings.audioEnabled ? await playReminderAudio() : createDisabledReminderAudioDebugInfo();
    recordReminderAudioDebug(debugInfo);
    return debugInfo;
  };
  const triggerReminder = async () => {
    const dismissed = overlay.show(DEFAULT_REMINDER_SPEECH, "reminder", getReminderPresentation(settings));
    await playReminder();
    await dismissed;
  };
  const applySettings = async (nextSettings) => {
    if (areSettingsEqual(settings, nextSettings)) {
      return;
    }
    settings = nextSettings;
    scheduler.setReminderIntervalMs(getReminderIntervalMs(settings));
    await syncSchedule(Date.now());
  };
  const markInteraction = () => {
    session.markInteraction(Date.now());
    void reportToolbarIconState(session.isActive(Date.now()));
  };
  ["scroll", "click", "keydown", "wheel"].forEach((eventName) => {
    win.addEventListener(eventName, markInteraction, { passive: true });
  });
  doc.addEventListener("visibilitychange", () => {
    session.setVisibility(doc.visibilityState === "visible", Date.now());
    void reportToolbarIconState(session.isActive(Date.now()));
    if (doc.visibilityState !== "visible") {
      void persistRuntimeStatus({
        isActiveReading: false,
        nextEligibleReminderAt: null
      });
    }
  });
  const previewReminder = createPreviewReminderRunner({
    overlay,
    playReminder,
    getPresentation: () => getReminderPresentation(settings)
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type !== "preview-reminder") {
      return false;
    }
    void previewReminder();
    return false;
  });
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes[STORAGE_KEY]) {
      return;
    }
    void (async () => {
      const latest = await storage.loadState();
      await applySettings(latest.settings);
    })();
  });
  markInteraction();
  await syncSchedule(Date.now());
  await reportToolbarIconState(session.isActive(Date.now()));
  win.setInterval(() => {
    void (async () => {
      const now = Date.now();
      if (overlay.isBlockingReminderVisible()) {
        await persistRuntimeStatus({
          isActiveReading: false,
          nextEligibleReminderAt: null
        });
        return;
      }
      const schedule = await syncSchedule(now);
      if (!schedule.isActive) {
        return;
      }
      recordReadingSample(stats, {
        date: getTodayDate(),
        bookTitle: getWeReadBookTitle(doc),
        readingTimeMs: STATS_SAMPLE_INTERVAL_MS
      });
      await persistStats();
      if (!schedule.reminderDue) {
        return;
      }
      recordReminderTriggered(stats, {
        date: getTodayDate(),
        bookTitle: getWeReadBookTitle(doc)
      });
      await persistStats();
      scheduler.markReminderTriggered(now);
      await persistRuntimeStatus({
        activeReadingTimeMs: 0,
        isActiveReading: true,
        nextEligibleReminderAt: now + getReminderIntervalMs(settings)
      });
      await triggerReminder();
    })();
  }, STATS_SAMPLE_INTERVAL_MS);
}
if (document.readyState === "loading") {
  document.addEventListener(
    "DOMContentLoaded",
    () => {
      void bootstrap(document, window);
    },
    { once: true }
  );
} else {
  void bootstrap(document, window);
}
//# sourceMappingURL=main.js.map
