// src/shared/constants.ts
var DEFAULT_POLICY = {
  inactivityTimeoutMs: 3 * 6e4,
  reminderIntervalMs: 20 * 6e4
};
var DEFAULT_REMINDER_SETTINGS = {
  reminderIntervalMinutes: 20,
  audioEnabled: true,
  fullscreenReminder: true
};
var REMINDER_INTERVAL_OPTIONS = [15, 20, 30];

// src/shared/stats.ts
function createBookStats(title) {
  return {
    title,
    readingTimeMs: 0,
    reminderCount: 0
  };
}
function createDayStats(date) {
  return {
    date,
    readingTimeMs: 0,
    reminderCount: 0,
    books: {}
  };
}
function createEmptyStatsState() {
  return { days: {} };
}
function normalizeBookStats(bookTitle, book) {
  if (!book || typeof book !== "object") {
    return createBookStats(bookTitle);
  }
  const raw = book;
  return {
    title: typeof raw.title === "string" ? raw.title : bookTitle,
    readingTimeMs: typeof raw.readingTimeMs === "number" ? raw.readingTimeMs : 0,
    reminderCount: typeof raw.reminderCount === "number" ? raw.reminderCount : 0
  };
}
function normalizeDayStats(date, day) {
  if (!day || typeof day !== "object") {
    return createDayStats(date);
  }
  const raw = day;
  const books = Object.fromEntries(
    Object.entries(raw.books ?? {}).map(([bookTitle, book]) => [bookTitle, normalizeBookStats(bookTitle, book)])
  );
  return {
    date: typeof raw.date === "string" ? raw.date : date,
    readingTimeMs: typeof raw.readingTimeMs === "number" ? raw.readingTimeMs : 0,
    reminderCount: typeof raw.reminderCount === "number" ? raw.reminderCount : 0,
    books
  };
}
function normalizeStatsState(state) {
  if (!state || typeof state !== "object") {
    return createEmptyStatsState();
  }
  const raw = state;
  return {
    days: Object.fromEntries(Object.entries(raw.days ?? {}).map(([date, day]) => [date, normalizeDayStats(date, day)]))
  };
}

// src/shared/storage.ts
var STORAGE_KEY = "weread-eye-care-state";
function getDefaultState() {
  return {
    stats: createEmptyStatsState(),
    activeReadingTimeMs: 0,
    isActiveReading: false,
    nextEligibleReminderAt: null,
    settings: DEFAULT_REMINDER_SETTINGS
  };
}
function normalizeSettings(stored) {
  if (!stored || typeof stored !== "object") {
    return DEFAULT_REMINDER_SETTINGS;
  }
  const raw = stored;
  const reminderIntervalMinutes = raw.reminderIntervalMinutes === 15 || raw.reminderIntervalMinutes === 20 || raw.reminderIntervalMinutes === 30 ? raw.reminderIntervalMinutes : DEFAULT_REMINDER_SETTINGS.reminderIntervalMinutes;
  return {
    reminderIntervalMinutes,
    audioEnabled: typeof raw.audioEnabled === "boolean" ? raw.audioEnabled : DEFAULT_REMINDER_SETTINGS.audioEnabled,
    fullscreenReminder: typeof raw.fullscreenReminder === "boolean" ? raw.fullscreenReminder : DEFAULT_REMINDER_SETTINGS.fullscreenReminder
  };
}
function normalizeState(stored) {
  if (!stored || typeof stored !== "object") {
    return getDefaultState();
  }
  const raw = stored;
  return {
    stats: normalizeStatsState(raw.stats),
    activeReadingTimeMs: typeof raw.activeReadingTimeMs === "number" ? raw.activeReadingTimeMs : 0,
    isActiveReading: typeof raw.isActiveReading === "boolean" ? raw.isActiveReading : false,
    nextEligibleReminderAt: typeof raw.nextEligibleReminderAt === "number" ? raw.nextEligibleReminderAt : null,
    settings: normalizeSettings(raw.settings)
  };
}
var AppStorage = class {
  constructor(storageArea = chrome.storage.local) {
    this.storageArea = storageArea;
  }
  async loadState() {
    const data = await this.storageArea.get(STORAGE_KEY);
    return normalizeState(data[STORAGE_KEY]);
  }
  async saveState(state) {
    await this.storageArea.set({ [STORAGE_KEY]: state });
  }
  async loadStats() {
    const state = await this.loadState();
    return state.stats;
  }
  async saveStats(stats) {
    const state = await this.loadState();
    await this.saveState({ ...state, stats });
  }
  async setRuntimeStatus(status) {
    const state = await this.loadState();
    await this.saveState({ ...state, ...status });
  }
  async saveSettings(settings) {
    const state = await this.loadState();
    await this.saveState({ ...state, settings });
  }
  async resetState() {
    await this.saveState(getDefaultState());
  }
};

// src/shared/csv.ts
function escapeCsvValue(value) {
  const text = String(value);
  if (/[,"\n]/.test(text)) {
    return `"${text.replaceAll('"', '""')}"`;
  }
  return text;
}
function exportBookStatsCsv(state) {
  const header = ["date", "bookTitle", "readingMinutes", "reminderCount"];
  const rows = Object.values(state.days).sort((left, right) => left.date.localeCompare(right.date)).flatMap(
    (day) => Object.values(day.books).sort((left, right) => left.title.localeCompare(right.title)).map(
      (book) => [day.date, book.title, Math.round(book.readingTimeMs / 6e4), book.reminderCount].map(escapeCsvValue).join(",")
    )
  );
  return [header.join(","), ...rows].join("\n");
}

// src/options/export.ts
function buildExportFilename(date) {
  return `weread-eye-care-${date}.csv`;
}
function downloadCsv(filename, contents, {
  createObjectURL = URL.createObjectURL.bind(URL),
  revokeObjectURL = URL.revokeObjectURL.bind(URL),
  createElement = (tagName) => document.createElement(tagName),
  setTimeout = window.setTimeout.bind(window)
} = {}) {
  const blob = new Blob([contents], { type: "text/csv;charset=utf-8" });
  const url = createObjectURL(blob);
  const anchor = createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  setTimeout(() => {
    revokeObjectURL(url);
  }, 0);
}

// src/ui/summary.ts
function buildStatsSummary(state, todayDate) {
  const today2 = state.days[todayDate];
  return {
    todayReadingMinutes: Math.round((today2?.readingTimeMs ?? 0) / 6e4),
    todayReminderCount: today2?.reminderCount ?? 0
  };
}
function formatCompactDuration(durationMs) {
  const totalSeconds = Math.max(0, Math.floor(durationMs / 1e3));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}\u5206${String(seconds).padStart(2, "0")}\u79D2`;
}
function buildReadingStatusLabel(isActiveReading, activeReadingTimeMs) {
  const duration = formatCompactDuration(activeReadingTimeMs);
  const prefix = isActiveReading ? "\u8BA1\u65F6\u4E2D" : "\u5DF2\u6682\u505C";
  return `${prefix} \xB7 ${duration}`;
}
function formatNextEligibleReminder(nextEligibleReminderAt, now) {
  return `${formatCompactDuration(nextEligibleReminderAt - now)}\u540E`;
}
function buildReminderStatusSummary(state, now) {
  const isActiveReading = state.isActiveReading ?? false;
  const nextEligibleReminderAt = state.nextEligibleReminderAt;
  const activeReadingTimeMs = state.activeReadingTimeMs ?? 0;
  return {
    readingStatusLabel: buildReadingStatusLabel(isActiveReading, activeReadingTimeMs),
    nextEligibleReminderLabel: !isActiveReading ? "\u7B49\u5F85\u5F00\u59CB\u9605\u8BFB" : nextEligibleReminderAt !== null && nextEligibleReminderAt > now ? formatNextEligibleReminder(nextEligibleReminderAt, now) : "\u53EF\u7ACB\u5373\u89E6\u53D1"
  };
}

// src/options/view-model.ts
function buildOptionsViewModel(state, todayDate, now = Date.now()) {
  const status = buildReminderStatusSummary(state, now);
  return {
    readingStatusLabel: status.readingStatusLabel,
    nextReminderLabel: status.nextEligibleReminderLabel,
    summary: buildStatsSummary(state.stats, todayDate)
  };
}

// src/options/main.ts
function today() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function parseReminderIntervalMinutes(value) {
  const minutes = Number(value);
  return minutes === 15 || minutes === 20 || minutes === 30 ? minutes : 20;
}
async function render(settingsStatusMessage = "\u4FEE\u6539\u540E\u4F1A\u7ACB\u5373\u4FDD\u5B58\u5E76\u540C\u6B65\u5230\u5F53\u524D\u9605\u8BFB\u9875\u3002") {
  const storage = new AppStorage();
  const state = await storage.loadState();
  const viewModel = buildOptionsViewModel(state, today());
  const app = document.getElementById("app");
  if (!app) {
    return;
  }
  app.innerHTML = `
    <section class="card">
      <h1>\u5FAE\u4FE1\u8BFB\u4E66\u62A4\u773C\u6269\u5C55</h1>
      <p>\u6269\u5C55\u53EA\u6309\u4F60\u7684\u6D3B\u8DC3\u9605\u8BFB\u65F6\u957F\u63D0\u9192\u3002</p>
      <div class="metrics">
        <div class="metric"><div>\u4ECA\u65E5\u9605\u8BFB</div><strong>${viewModel.summary.todayReadingMinutes} \u5206\u949F</strong></div>
        <div class="metric"><div>\u4ECA\u65E5\u63D0\u9192</div><strong>${viewModel.summary.todayReminderCount} \u6B21</strong></div>
        <div class="metric"><div>\u9605\u8BFB\u72B6\u6001</div><strong>${viewModel.readingStatusLabel}</strong></div>
        <div class="metric"><div>\u4E0B\u6B21\u63D0\u9192</div><strong>${viewModel.nextReminderLabel}</strong></div>
      </div>
      <section class="settings">
        <h2>\u63D0\u9192\u8BBE\u7F6E</h2>
        <label class="setting">
          <span>\u63D0\u9192\u95F4\u9694</span>
          <select id="reminder-interval">
            ${REMINDER_INTERVAL_OPTIONS.map((minutes) => {
    const selected = state.settings.reminderIntervalMinutes === minutes ? "selected" : "";
    return `<option value="${minutes}" ${selected}>${minutes} \u5206\u949F</option>`;
  }).join("")}
          </select>
        </label>
        <label class="setting checkbox">
          <input id="audio-enabled" type="checkbox" ${state.settings.audioEnabled ? "checked" : ""} />
          <span>\u64AD\u653E\u63D0\u9192\u8BED\u97F3</span>
        </label>
        <label class="setting checkbox">
          <input id="fullscreen-reminder" type="checkbox" ${state.settings.fullscreenReminder ? "checked" : ""} />
          <span>\u4F7F\u7528\u5168\u5C4F\u63D0\u9192</span>
        </label>
        <p id="settings-status" class="settings-status">${settingsStatusMessage}</p>
      </section>
      <div class="actions">
        <button id="export">\u5BFC\u51FA CSV</button>
        <button id="reset" class="secondary">\u6E05\u7A7A\u672C\u5730\u7EDF\u8BA1</button>
      </div>
      <p>\u5F53\u4F60\u5728\u5FAE\u4FE1\u8BFB\u4E66\u9875\u9762\u6301\u7EED\u6D3B\u8DC3\u9605\u8BFB\u7D2F\u8BA1 ${state.settings.reminderIntervalMinutes} \u5206\u949F\u65F6\uFF0C\u6269\u5C55\u4F1A\u5F39\u51FA\u63D0\u9192${state.settings.audioEnabled ? "\u5E76\u64AD\u653E\u56FA\u5B9A\u8BED\u97F3" : ""}\u3002</p>
      <p>\u5BFC\u51FA\u6587\u4EF6\u53EA\u5305\u542B\u5F53\u524D\u7248\u672C\u5B9E\u9645\u4FDD\u5B58\u7684\u6570\u636E\uFF1A\u65E5\u671F\u3001\u4E66\u540D\u3001\u9605\u8BFB\u5206\u949F\u6570\u3001\u63D0\u9192\u6B21\u6570\u3002</p>
    </section>
  `;
  const readSettings = () => ({
    reminderIntervalMinutes: parseReminderIntervalMinutes(
      document.getElementById("reminder-interval")?.value ?? String(state.settings.reminderIntervalMinutes)
    ),
    audioEnabled: Boolean(document.getElementById("audio-enabled")?.checked),
    fullscreenReminder: Boolean(
      document.getElementById("fullscreen-reminder")?.checked
    )
  });
  const persistSettings = async () => {
    await storage.saveSettings(readSettings());
    await render("\u63D0\u9192\u8BBE\u7F6E\u5DF2\u4FDD\u5B58\u3002");
  };
  document.getElementById("reminder-interval")?.addEventListener("change", () => {
    void persistSettings();
  });
  document.getElementById("audio-enabled")?.addEventListener("change", () => {
    void persistSettings();
  });
  document.getElementById("fullscreen-reminder")?.addEventListener("change", () => {
    void persistSettings();
  });
  document.getElementById("export")?.addEventListener("click", async () => {
    const latest = await storage.loadState();
    const csv = exportBookStatsCsv(latest.stats);
    downloadCsv(buildExportFilename(today()), csv);
  });
  document.getElementById("reset")?.addEventListener("click", async () => {
    await storage.resetState();
    await render("\u672C\u5730\u7EDF\u8BA1\u4E0E\u63D0\u9192\u8BBE\u7F6E\u90FD\u5DF2\u6062\u590D\u9ED8\u8BA4\u503C\u3002");
  });
}
void render();
//# sourceMappingURL=main.js.map
