// src/shared/constants.ts
var DEFAULT_POLICY = {
  inactivityTimeoutMs: 3 * 6e4,
  reminderIntervalMs: 20 * 6e4
};
var DEFAULT_REMINDER_SETTINGS = {
  reminderIntervalMinutes: 20,
  audioEnabled: true,
  fullscreenReminder: true
};

// src/shared/stats.ts
function createBookStats(title) {
  return {
    title,
    readingTimeMs: 0,
    reminderCount: 0
  };
}
function createDayStats(date) {
  return {
    date,
    readingTimeMs: 0,
    reminderCount: 0,
    books: {}
  };
}
function createEmptyStatsState() {
  return { days: {} };
}
function normalizeBookStats(bookTitle, book) {
  if (!book || typeof book !== "object") {
    return createBookStats(bookTitle);
  }
  const raw = book;
  return {
    title: typeof raw.title === "string" ? raw.title : bookTitle,
    readingTimeMs: typeof raw.readingTimeMs === "number" ? raw.readingTimeMs : 0,
    reminderCount: typeof raw.reminderCount === "number" ? raw.reminderCount : 0
  };
}
function normalizeDayStats(date, day) {
  if (!day || typeof day !== "object") {
    return createDayStats(date);
  }
  const raw = day;
  const books = Object.fromEntries(
    Object.entries(raw.books ?? {}).map(([bookTitle, book]) => [bookTitle, normalizeBookStats(bookTitle, book)])
  );
  return {
    date: typeof raw.date === "string" ? raw.date : date,
    readingTimeMs: typeof raw.readingTimeMs === "number" ? raw.readingTimeMs : 0,
    reminderCount: typeof raw.reminderCount === "number" ? raw.reminderCount : 0,
    books
  };
}
function normalizeStatsState(state) {
  if (!state || typeof state !== "object") {
    return createEmptyStatsState();
  }
  const raw = state;
  return {
    days: Object.fromEntries(Object.entries(raw.days ?? {}).map(([date, day]) => [date, normalizeDayStats(date, day)]))
  };
}

// src/shared/storage.ts
var STORAGE_KEY = "weread-eye-care-state";
function getDefaultState() {
  return {
    stats: createEmptyStatsState(),
    activeReadingTimeMs: 0,
    isActiveReading: false,
    nextEligibleReminderAt: null,
    settings: DEFAULT_REMINDER_SETTINGS
  };
}
function normalizeSettings(stored) {
  if (!stored || typeof stored !== "object") {
    return DEFAULT_REMINDER_SETTINGS;
  }
  const raw = stored;
  const reminderIntervalMinutes = raw.reminderIntervalMinutes === 15 || raw.reminderIntervalMinutes === 20 || raw.reminderIntervalMinutes === 30 ? raw.reminderIntervalMinutes : DEFAULT_REMINDER_SETTINGS.reminderIntervalMinutes;
  return {
    reminderIntervalMinutes,
    audioEnabled: typeof raw.audioEnabled === "boolean" ? raw.audioEnabled : DEFAULT_REMINDER_SETTINGS.audioEnabled,
    fullscreenReminder: typeof raw.fullscreenReminder === "boolean" ? raw.fullscreenReminder : DEFAULT_REMINDER_SETTINGS.fullscreenReminder
  };
}
function normalizeState(stored) {
  if (!stored || typeof stored !== "object") {
    return getDefaultState();
  }
  const raw = stored;
  return {
    stats: normalizeStatsState(raw.stats),
    activeReadingTimeMs: typeof raw.activeReadingTimeMs === "number" ? raw.activeReadingTimeMs : 0,
    isActiveReading: typeof raw.isActiveReading === "boolean" ? raw.isActiveReading : false,
    nextEligibleReminderAt: typeof raw.nextEligibleReminderAt === "number" ? raw.nextEligibleReminderAt : null,
    settings: normalizeSettings(raw.settings)
  };
}
var AppStorage = class {
  constructor(storageArea = chrome.storage.local) {
    this.storageArea = storageArea;
  }
  async loadState() {
    const data = await this.storageArea.get(STORAGE_KEY);
    return normalizeState(data[STORAGE_KEY]);
  }
  async saveState(state) {
    await this.storageArea.set({ [STORAGE_KEY]: state });
  }
  async loadStats() {
    const state = await this.loadState();
    return state.stats;
  }
  async saveStats(stats) {
    const state = await this.loadState();
    await this.saveState({ ...state, stats });
  }
  async setRuntimeStatus(status) {
    const state = await this.loadState();
    await this.saveState({ ...state, ...status });
  }
  async saveSettings(settings) {
    const state = await this.loadState();
    await this.saveState({ ...state, settings });
  }
  async resetState() {
    await this.saveState(getDefaultState());
  }
};

// src/ui/summary.ts
function buildStatsSummary(state, todayDate) {
  const today2 = state.days[todayDate];
  return {
    todayReadingMinutes: Math.round((today2?.readingTimeMs ?? 0) / 6e4),
    todayReminderCount: today2?.reminderCount ?? 0
  };
}
function formatCompactDuration(durationMs) {
  const totalSeconds = Math.max(0, Math.floor(durationMs / 1e3));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}\u5206${String(seconds).padStart(2, "0")}\u79D2`;
}
function buildReadingStatusLabel(isActiveReading, activeReadingTimeMs) {
  const duration = formatCompactDuration(activeReadingTimeMs);
  const prefix = isActiveReading ? "\u8BA1\u65F6\u4E2D" : "\u5DF2\u6682\u505C";
  return `${prefix} \xB7 ${duration}`;
}
function formatNextEligibleReminder(nextEligibleReminderAt, now) {
  return `${formatCompactDuration(nextEligibleReminderAt - now)}\u540E`;
}
function buildReminderStatusSummary(state, now) {
  const isActiveReading = state.isActiveReading ?? false;
  const nextEligibleReminderAt = state.nextEligibleReminderAt;
  const activeReadingTimeMs = state.activeReadingTimeMs ?? 0;
  return {
    readingStatusLabel: buildReadingStatusLabel(isActiveReading, activeReadingTimeMs),
    nextEligibleReminderLabel: !isActiveReading ? "\u7B49\u5F85\u5F00\u59CB\u9605\u8BFB" : nextEligibleReminderAt !== null && nextEligibleReminderAt > now ? formatNextEligibleReminder(nextEligibleReminderAt, now) : "\u53EF\u7ACB\u5373\u89E6\u53D1"
  };
}

// src/content/weread/adapter.ts
var WEREAD_READER_PATH = "/web/reader/";
function isSupportedWeReadUrl(url) {
  return url.hostname === "weread.qq.com" && url.pathname.startsWith(WEREAD_READER_PATH);
}

// src/popup/preview.ts
var PREVIEW_DISABLED_HINT = "\u4EC5\u5728\u5FAE\u4FE1\u8BFB\u4E66\u9605\u8BFB\u9875\u53EF\u9884\u89C8";
var PREVIEW_REMINDER_COMMAND = "preview-reminder";
function buildPreviewReminderState(tab) {
  if (typeof tab?.id !== "number" || typeof tab.url !== "string") {
    return {
      enabled: false,
      tabId: null,
      hint: PREVIEW_DISABLED_HINT
    };
  }
  try {
    const supported = isSupportedWeReadUrl(new URL(tab.url));
    return supported ? {
      enabled: true,
      tabId: tab.id,
      hint: null
    } : {
      enabled: false,
      tabId: null,
      hint: PREVIEW_DISABLED_HINT
    };
  } catch {
    return {
      enabled: false,
      tabId: null,
      hint: PREVIEW_DISABLED_HINT
    };
  }
}

// src/popup/actions.ts
function bindPopupActions({
  root,
  onPreview,
  onOpenSettings
}) {
  root.querySelector("#preview-reminder")?.addEventListener("click", () => {
    void onPreview();
  });
  root.querySelector("#open-settings")?.addEventListener("click", () => {
    void onOpenSettings();
  });
}

// src/popup/live-status.ts
function derivePopupRuntimeState(state, popupOpenedAt, now) {
  if (!state.isActiveReading) {
    return state;
  }
  return {
    ...state,
    activeReadingTimeMs: state.activeReadingTimeMs + Math.max(0, now - popupOpenedAt)
  };
}

// src/popup/main.ts
function today() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0] ?? null;
}
async function render() {
  const storage = new AppStorage();
  const state = await storage.loadState();
  const summary = buildStatsSummary(state.stats, today());
  const activeTab = await getActiveTab();
  const previewState = buildPreviewReminderState(activeTab);
  const app = document.getElementById("app");
  if (!app) {
    return;
  }
  const popupOpenedAt = Date.now();
  const updateStatus = () => {
    const liveState = derivePopupRuntimeState(state, popupOpenedAt, Date.now());
    const status = buildReminderStatusSummary(liveState, Date.now());
    const readingStatusNode = document.getElementById("reading-status-value");
    const nextReminderNode = document.getElementById("next-reminder-value");
    if (readingStatusNode) {
      readingStatusNode.textContent = previewState.enabled ? status.readingStatusLabel : "\u5DF2\u6682\u505C \xB7 0\u520600\u79D2";
    }
    if (nextReminderNode) {
      nextReminderNode.textContent = previewState.enabled ? status.nextEligibleReminderLabel : "\u7B49\u5F85\u5F00\u59CB\u9605\u8BFB";
    }
  };
  app.innerHTML = `
    <section class="panel">
      <h1>\u5FAE\u4FE1\u8BFB\u4E66\u62A4\u773C</h1>
      <div>\u5FAE\u4FE1\u8BFB\u4E66\u9605\u8BFB\u63D0\u9192</div>
      <div class="grid">
        <div class="metric"><span>\u4ECA\u65E5\u9605\u8BFB</span><strong>${summary.todayReadingMinutes} \u5206\u949F</strong></div>
        <div class="metric"><span>\u4ECA\u65E5\u63D0\u9192</span><strong>${summary.todayReminderCount} \u6B21</strong></div>
        <div class="metric"><span>\u9605\u8BFB\u72B6\u6001</span><strong id="reading-status-value"></strong></div>
        <div class="metric"><span>\u4E0B\u6B21\u63D0\u9192</span><strong id="next-reminder-value"></strong></div>
      </div>
      <div class="actions">
        <button id="preview-reminder" ${previewState.enabled ? "" : "disabled"}>\u9884\u89C8\u63D0\u9192</button>
        <button id="open-settings" class="secondary">\u63D0\u9192\u8BBE\u7F6E</button>
      </div>
    </section>
  `;
  updateStatus();
  window.setInterval(updateStatus, 1e3);
  bindPopupActions({
    root: document,
    onPreview: async () => {
      if (!previewState.enabled || previewState.tabId === null) {
        return;
      }
      try {
        await chrome.tabs.sendMessage(previewState.tabId, {
          type: PREVIEW_REMINDER_COMMAND
        });
      } catch {
      }
    },
    onOpenSettings: async () => {
      await chrome.runtime.openOptionsPage();
    }
  });
}
void render();
//# sourceMappingURL=main.js.map
