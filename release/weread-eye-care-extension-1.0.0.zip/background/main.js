// src/background/icon.ts
var THEMES = {
  active: {
    backgroundStart: "#9EDB8A",
    backgroundEnd: "#2D6A4F",
    leafStart: "#E6F6D8",
    leafEnd: "#C8E7AD",
    accent: "#F7FFF0"
  },
  paused: {
    backgroundStart: "#D5CFC3",
    backgroundEnd: "#8B8478",
    leafStart: "#F2EEE7",
    leafEnd: "#D9D1C5",
    accent: "#FFF8EE"
  }
};
var BADGE_THEMES = {
  active: {
    text: "\u8BFB",
    backgroundColor: "#2D6A4F",
    textColor: "#FFFFFF"
  },
  paused: {
    text: "\u505C",
    backgroundColor: "#8B8478",
    textColor: "#FFFFFF"
  }
};
function getToolbarIconState({
  isSupportedPage,
  isActiveReading
}) {
  return isSupportedPage && isActiveReading ? "active" : "paused";
}
function buildToolbarIconSvg(state) {
  const theme = THEMES[state];
  return `<svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="16" y1="12" x2="112" y2="116" gradientUnits="userSpaceOnUse">
      <stop stop-color="${theme.backgroundStart}"/>
      <stop offset="1" stop-color="${theme.backgroundEnd}"/>
    </linearGradient>
    <linearGradient id="leaf" x1="63" y1="46" x2="84" y2="68" gradientUnits="userSpaceOnUse">
      <stop stop-color="${theme.leafStart}"/>
      <stop offset="1" stop-color="${theme.leafEnd}"/>
    </linearGradient>
  </defs>
  <rect x="8" y="8" width="112" height="112" rx="28" fill="url(#bg)"/>
  <path
    d="M22 64C29.2 47.2 45.6 36 64 36C82.4 36 98.8 47.2 106 64C98.8 80.8 82.4 92 64 92C45.6 92 29.2 80.8 22 64Z"
    fill="${theme.accent}"
  />
  <path
    d="M28 64C34 50.8 47.8 42 64 42C80.2 42 94 50.8 100 64C94 77.2 80.2 86 64 86C47.8 86 34 77.2 28 64Z"
    fill="#1C2C3B"
  />
  <circle cx="64" cy="64" r="15" fill="${theme.accent}"/>
  <circle cx="64" cy="64" r="8" fill="#1C2C3B"/>
  <path
    d="M72 42C82 41.6 90.4 49.1 90.8 59.1C80.9 59.5 72.4 52 72 42Z"
    fill="url(#leaf)"
  />
  <path
    d="M74.5 45.5C79.4 48.9 83 53.3 85.4 58.7"
    stroke="#EAF7DA"
    stroke-width="3"
    stroke-linecap="round"
  />
  <circle cx="48" cy="55" r="4" fill="${theme.accent}" fill-opacity="0.9"/>
</svg>`;
}
function buildToolbarBadge(state) {
  return BADGE_THEMES[state];
}

// src/shared/messages.ts
var TOOLBAR_ICON_STATE_COMMAND = "toolbar-icon-state";

// src/background/toolbar-action.ts
async function applyToolbarActionVisuals({
  actionApi,
  iconState,
  iconImageData,
  tabId
}) {
  const badge = buildToolbarBadge(iconState);
  if (iconImageData) {
    if (typeof tabId === "number") {
      await actionApi.setIcon({ tabId, imageData: iconImageData });
    } else {
      await actionApi.setIcon({ imageData: iconImageData });
    }
  }
  if (typeof tabId === "number") {
    await actionApi.setBadgeText({ tabId, text: badge.text });
    await actionApi.setBadgeBackgroundColor({ tabId, color: badge.backgroundColor });
    await actionApi.setBadgeTextColor({ tabId, color: badge.textColor });
    return;
  }
  await actionApi.setBadgeText({ text: badge.text });
  await actionApi.setBadgeBackgroundColor({ color: badge.backgroundColor });
  await actionApi.setBadgeTextColor({ color: badge.textColor });
}

// src/content/weread/adapter.ts
var WEREAD_READER_PATH = "/web/reader/";
function isSupportedWeReadUrl(url) {
  return url.hostname === "weread.qq.com" && url.pathname.startsWith(WEREAD_READER_PATH);
}

// src/background/toolbar-state.ts
function resolveToolbarIconStateForTab({
  tabUrl,
  runtimeState,
  persistedIsActiveReading
}) {
  if (runtimeState) {
    return runtimeState;
  }
  if (typeof tabUrl !== "string") {
    return "paused";
  }
  try {
    return isSupportedWeReadUrl(new URL(tabUrl)) && persistedIsActiveReading ? "active" : "paused";
  } catch {
    return "paused";
  }
}

// src/shared/constants.ts
var DEFAULT_POLICY = {
  inactivityTimeoutMs: 3 * 6e4,
  reminderIntervalMs: 20 * 6e4
};
var DEFAULT_REMINDER_SETTINGS = {
  reminderIntervalMinutes: 20,
  audioEnabled: true,
  fullscreenReminder: true
};

// src/shared/stats.ts
function createBookStats(title) {
  return {
    title,
    readingTimeMs: 0,
    reminderCount: 0
  };
}
function createDayStats(date) {
  return {
    date,
    readingTimeMs: 0,
    reminderCount: 0,
    books: {}
  };
}
function createEmptyStatsState() {
  return { days: {} };
}
function normalizeBookStats(bookTitle, book) {
  if (!book || typeof book !== "object") {
    return createBookStats(bookTitle);
  }
  const raw = book;
  return {
    title: typeof raw.title === "string" ? raw.title : bookTitle,
    readingTimeMs: typeof raw.readingTimeMs === "number" ? raw.readingTimeMs : 0,
    reminderCount: typeof raw.reminderCount === "number" ? raw.reminderCount : 0
  };
}
function normalizeDayStats(date, day) {
  if (!day || typeof day !== "object") {
    return createDayStats(date);
  }
  const raw = day;
  const books = Object.fromEntries(
    Object.entries(raw.books ?? {}).map(([bookTitle, book]) => [bookTitle, normalizeBookStats(bookTitle, book)])
  );
  return {
    date: typeof raw.date === "string" ? raw.date : date,
    readingTimeMs: typeof raw.readingTimeMs === "number" ? raw.readingTimeMs : 0,
    reminderCount: typeof raw.reminderCount === "number" ? raw.reminderCount : 0,
    books
  };
}
function normalizeStatsState(state) {
  if (!state || typeof state !== "object") {
    return createEmptyStatsState();
  }
  const raw = state;
  return {
    days: Object.fromEntries(Object.entries(raw.days ?? {}).map(([date, day]) => [date, normalizeDayStats(date, day)]))
  };
}

// src/shared/storage.ts
var STORAGE_KEY = "weread-eye-care-state";
function getDefaultState() {
  return {
    stats: createEmptyStatsState(),
    activeReadingTimeMs: 0,
    isActiveReading: false,
    nextEligibleReminderAt: null,
    settings: DEFAULT_REMINDER_SETTINGS
  };
}
function normalizeSettings(stored) {
  if (!stored || typeof stored !== "object") {
    return DEFAULT_REMINDER_SETTINGS;
  }
  const raw = stored;
  const reminderIntervalMinutes = raw.reminderIntervalMinutes === 15 || raw.reminderIntervalMinutes === 20 || raw.reminderIntervalMinutes === 30 ? raw.reminderIntervalMinutes : DEFAULT_REMINDER_SETTINGS.reminderIntervalMinutes;
  return {
    reminderIntervalMinutes,
    audioEnabled: typeof raw.audioEnabled === "boolean" ? raw.audioEnabled : DEFAULT_REMINDER_SETTINGS.audioEnabled,
    fullscreenReminder: typeof raw.fullscreenReminder === "boolean" ? raw.fullscreenReminder : DEFAULT_REMINDER_SETTINGS.fullscreenReminder
  };
}
function normalizeState(stored) {
  if (!stored || typeof stored !== "object") {
    return getDefaultState();
  }
  const raw = stored;
  return {
    stats: normalizeStatsState(raw.stats),
    activeReadingTimeMs: typeof raw.activeReadingTimeMs === "number" ? raw.activeReadingTimeMs : 0,
    isActiveReading: typeof raw.isActiveReading === "boolean" ? raw.isActiveReading : false,
    nextEligibleReminderAt: typeof raw.nextEligibleReminderAt === "number" ? raw.nextEligibleReminderAt : null,
    settings: normalizeSettings(raw.settings)
  };
}
var AppStorage = class {
  constructor(storageArea = chrome.storage.local) {
    this.storageArea = storageArea;
  }
  async loadState() {
    const data = await this.storageArea.get(STORAGE_KEY);
    return normalizeState(data[STORAGE_KEY]);
  }
  async saveState(state) {
    await this.storageArea.set({ [STORAGE_KEY]: state });
  }
  async loadStats() {
    const state = await this.loadState();
    return state.stats;
  }
  async saveStats(stats) {
    const state = await this.loadState();
    await this.saveState({ ...state, stats });
  }
  async setRuntimeStatus(status) {
    const state = await this.loadState();
    await this.saveState({ ...state, ...status });
  }
  async saveSettings(settings) {
    const state = await this.loadState();
    await this.saveState({ ...state, settings });
  }
  async resetState() {
    await this.saveState(getDefaultState());
  }
};

// src/background/main.ts
var ICON_SIZES = [16, 32];
var tabStates = /* @__PURE__ */ new Map();
var iconCache = /* @__PURE__ */ new Map();
var storage = new AppStorage();
async function renderSvgToImageData(svg, size) {
  const blob = new Blob([svg], { type: "image/svg+xml" });
  const bitmap = await createImageBitmap(blob, {
    resizeWidth: size,
    resizeHeight: size
  });
  const canvas = new OffscreenCanvas(size, size);
  const context = canvas.getContext("2d");
  if (!context) {
    throw new Error("Unable to render toolbar icon.");
  }
  context.clearRect(0, 0, size, size);
  context.drawImage(bitmap, 0, 0, size, size);
  return context.getImageData(0, 0, size, size);
}
function getIconImageData(state) {
  const cached = iconCache.get(state);
  if (cached) {
    return cached;
  }
  const renderPromise = Promise.all(
    ICON_SIZES.map(async (size) => [size, await renderSvgToImageData(buildToolbarIconSvg(state), size)])
  ).then((entries) => Object.fromEntries(entries));
  iconCache.set(state, renderPromise);
  return renderPromise;
}
async function applyToolbarIconForTab(tab) {
  const persisted = await storage.loadState();
  const iconState = resolveToolbarIconStateForTab({
    tabUrl: tab?.url,
    runtimeState: typeof tab?.id === "number" ? tabStates.get(tab.id) : void 0,
    persistedIsActiveReading: persisted.isActiveReading
  });
  let imageData = null;
  try {
    imageData = await getIconImageData(iconState);
  } catch (error) {
    console.warn("Failed to render toolbar icon, falling back to badge-only state.", error);
  }
  await applyToolbarActionVisuals({
    actionApi: chrome.action,
    iconState,
    iconImageData: imageData,
    tabId: tab?.id
  });
}
async function refreshActiveTabIcon() {
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await applyToolbarIconForTab(activeTab);
}
chrome.runtime.onInstalled.addListener(() => {
  console.info("WeRead Eye Care extension installed.");
  void refreshActiveTabIcon();
});
chrome.runtime.onStartup.addListener(() => {
  void refreshActiveTabIcon();
});
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type !== TOOLBAR_ICON_STATE_COMMAND || typeof sender.tab?.id !== "number") {
    return false;
  }
  const tabId = sender.tab.id;
  tabStates.set(
    tabId,
    getToolbarIconState({
      isSupportedPage: message.isSupportedPage,
      isActiveReading: message.isActiveReading
    })
  );
  void chrome.tabs.query({ active: true, currentWindow: true }).then(([activeTab]) => {
    if (activeTab?.id === tabId) {
      return applyToolbarIconForTab(activeTab);
    }
  }).catch(() => void 0);
  return false;
});
chrome.tabs.onActivated.addListener(({ tabId }) => {
  void chrome.tabs.get(tabId).then((tab) => applyToolbarIconForTab(tab)).catch(() => void 0);
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "loading") {
    return;
  }
  tabStates.delete(tabId);
  if (tab.active) {
    void applyToolbarIconForTab(tab);
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  tabStates.delete(tabId);
});
//# sourceMappingURL=main.js.map
